// The custom parent class that allows the various setting needed to have 
// a choice of journals similar to what actor sheets get
class CustomJournalSheet extends JournalSheet {

	get journal(){
		return this.object;
	}

	static get defaultOptions() {
		const options = super.defaultOptions;
		options.baseApplication = "JournalSheet";
		options.classes.push('custom-journal');
		return options;
	}

}

/* CUSTOMIZE
 * Add any extra themes here: just copy-paste the whole block, changing only the class
 * name for the theme's name that will appear in the drop-down, and the name in single
 * quotes (here, dark-slate-journal) with whatever name you gave your theme in the .css
 * file
 */

class Newspaper extends CustomJournalSheet {
	static get defaultOptions() {
		const options = super.defaultOptions;
		options.classes.push('newspaper');
		return options;
	}

	/** @override */
  _createEditor(target, options, content) {
		console.log('Custom Journals | creating editor...')
    // Call the original _createEditor method to initialize the editor
    const editor = super._createEditor(target, options, content);

    // Example: Add a custom plugin or modify the schema here
    // This is a conceptual example; you'll need to adapt it to your specific needs

    // Create a custom mark for styling
    const customMark = {
      attrs: {style: {default: null}},
      parseDOM: [{tag: "span[style]", getAttrs: dom => ({style: dom.getAttribute("style")})}],
      toDOM: node => ["span", {style: node.attrs.style}, 0]
    };

    // Add or modify schema
    const newSchema = new editor.Schema({
      nodes: editor.schema.spec.nodes,
      marks: editor.schema.spec.marks.addToEnd('customStyle', customMark)
    });

    // Replace the existing schema of the editor
    editor.view.setProps({
      state: EditorState.create({
        doc: editor.view.state.doc,
        plugins: [...editor.view.state.plugins], // Add or modify plugins if needed
        schema: newSchema
      })
    });

    return editor;
  }
}

Hooks.on("init", (documentTypes) => {
console.log("Custom Journals | Registering the module's sheets.");

DocumentSheetConfig.registerSheet(Journal, "asc-newsaer-style-journal", Newspaper, { 
	label: "Newspaper",
	types: ["base"],
	makeDefault: false 
});

console.log("Custom Journals | Ready.")
});